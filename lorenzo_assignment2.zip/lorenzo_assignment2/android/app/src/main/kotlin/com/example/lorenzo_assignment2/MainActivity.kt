package com.example.lorenzo_assignment2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
